# Learn PvP

Eine responsive Minecraft-PvP-Lernwebsite mit dunklem Blau/Schwarz-Design.

## Lokal starten
Öffne `index.html` im Browser.

## Auf GitHub Pages veröffentlichen
1. Erstelle ein GitHub-Repository, z. B. `learn-pvp`.
2. Lade alle Dateien und den Ordner `assets` hoch.
3. Öffne **Settings → Pages**.
4. Wähle **Deploy from a branch**, dann `main` und `/ (root)`.
5. Speichern. GitHub zeigt dir anschließend die Website-Adresse.

## Bilder
- `assets/crystal.png`: Crystal
- `assets/mace-ely.png`: wird für Mace und Ely verwendet
- `assets/cart.png`: Cart
- Sonstige Skills: bewusst ohne Inventarbild

## Anpassungen
Die vorläufigen Kategorie-Beschreibungen stehen in `script.js` im Objekt `descriptions`.
Die Hintergrundmusik ist eine leise, original synthetisierte Ambient-Klangfläche und startet erst nach Klick auf „Musik aus“ / „Musik an“.
