const translations = {
  de: {
    home:"Startseite", strategiesNav:"Strategien", aboutNav:"Über die Website",
    eyebrow:"MINECRAFT PVP ACADEMY", heroTitle:"Master your",
    heroLine1:"Lerne Strategien. Verbessere deine Skills.", heroLine2:"Werde sicherer in jedem Fight.",
    discover:"Strategien entdecken", training:"DEIN TRAININGSBEREICH",
    categoriesTitle:"PvP Kategorien", categoriesIntro1:"Wähle eine Kategorie und entdecke", categoriesIntro2:"die wichtigsten Grundlagen.",
    maceCard:"Entdecke Mace-Kämpfe, Timing und den richtigen Einsatz deiner Ausrüstung.",
    cartCard:"Lerne die Grundlagen rund um Minecarts und ihre Rolle in PvP-Situationen.",
    crystalCard:"Verstehe die Ausrüstung, das Positioning und die Grundlagen von Crystal PvP.",
    elyCard:"Verbessere dein Movement und lerne die Grundlagen des Elytra-PvP.",
    skillsCard:"Weitere Tipps, Techniken und allgemeine Fähigkeiten für dein PvP.",
    aboutKicker:"LEARN. PRACTICE. IMPROVE.", aboutTitle:"Dein nächster Fight", aboutTitle2:"beginnt hier.",
    aboutText:"Learn PvP ist dein übersichtlicher Startpunkt, um Minecraft-PvP-Kategorien kennenzulernen und deine Spielweise Schritt für Schritt zu verbessern.",
    footerTag:"MADE FOR THE NEXT FIGHT.", modalKicker:"LEARN PVP / STRATEGIE",
    viewStrategy:"STRATEGIE ANSEHEN", viewSkills:"SKILLS ENTDECKEN",
    musicOn:"Musik an", musicOff:"Musik aus",
    maceAlt:"Minecraft Mace PvP Inventar", cartAlt:"Minecraft Cart PvP Inventar",
    crystalAlt:"Minecraft Crystal PvP Inventar", elyAlt:"Minecraft Elytra PvP Inventar"
  },
  en: {
    home:"Home", strategiesNav:"Strategies", aboutNav:"About",
    eyebrow:"MINECRAFT PVP ACADEMY", heroTitle:"Master your",
    heroLine1:"Learn strategies. Improve your skills.", heroLine2:"Become more confident in every fight.",
    discover:"Explore strategies", training:"YOUR TRAINING HUB",
    categoriesTitle:"PvP Categories", categoriesIntro1:"Choose a category and discover", categoriesIntro2:"the most important basics.",
    maceCard:"Explore Mace combat, timing, and how to use your equipment effectively.",
    cartCard:"Learn the basics of minecarts and their role in PvP situations.",
    crystalCard:"Understand the equipment, positioning, and basics of Crystal PvP.",
    elyCard:"Improve your movement and learn the basics of Elytra PvP.",
    skillsCard:"More tips, techniques, and general skills to improve your PvP.",
    aboutKicker:"LEARN. PRACTICE. IMPROVE.", aboutTitle:"Your next fight", aboutTitle2:"starts here.",
    aboutText:"Learn PvP is your clear starting point for exploring Minecraft PvP categories and improving your play step by step.",
    footerTag:"MADE FOR THE NEXT FIGHT.", modalKicker:"LEARN PVP / STRATEGY",
    viewStrategy:"VIEW STRATEGY", viewSkills:"EXPLORE SKILLS",
    musicOn:"Music on", musicOff:"Music off",
    maceAlt:"Minecraft Mace PvP inventory", cartAlt:"Minecraft Cart PvP inventory",
    crystalAlt:"Minecraft Crystal PvP inventory", elyAlt:"Minecraft Elytra PvP inventory"
  }
};
let currentLanguage = "de";
function applyLanguage(language) {
  currentLanguage = language;
  document.documentElement.lang = language;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (translations[language][key]) el.textContent = translations[language][key];
  });
  document.querySelectorAll("[data-i18n-alt]").forEach(el => {
    const key = el.dataset.i18nAlt;
    if (translations[language][key]) el.alt = translations[language][key];
  });
  document.getElementById("languageLabel").textContent = language.toUpperCase();
  document.getElementById("musicLabel").textContent = musicOn ? translations[language].musicOn : translations[language].musicOff;
  if (modal.classList.contains("open")) {
    const key = document.querySelector(".strategy-card[data-category]")?.dataset.category;
    const activeKey = Object.keys(names).find(k => names[k] === modalTitle.textContent || (language === "en" && namesEn[k] === modalTitle.textContent));
    if (activeKey) {
      modalTitle.textContent = language === "en" ? namesEn[activeKey] : names[activeKey];
      modalDescription.textContent = language === "en" ? descriptionsEn[activeKey] : descriptions[activeKey];
    }
  }
}
const descriptions = {
  mace:"Hier kannst du später deine Mace-PvP-Erklärung, Ausrüstungstipps und Strategien ergänzen.",
  cart:"Hier kannst du später deine Cart-PvP-Erklärung, Ausrüstungstipps und Strategien ergänzen.",
  crystal:"Hier kannst du später deine Crystal-PvP-Erklärung, Ausrüstungstipps und Strategien ergänzen.",
  ely:"Hier kannst du später deine Ely-PvP-Erklärung, Movement-Tipps und Strategien ergänzen.",
  skills:"Hier ist Platz für weitere PvP-Skills, allgemeine Tipps und Techniken."
};
const descriptionsEn = {
  mace:"Your Mace PvP guide, equipment tips, and strategies can be added here.",
  cart:"Your Cart PvP guide, equipment tips, and strategies can be added here.",
  crystal:"Your Crystal PvP guide, equipment tips, and strategies can be added here.",
  ely:"Your Elytra PvP guide, movement tips, and strategies can be added here.",
  skills:"This section is for more PvP skills, general tips, and techniques."
};
const names = {mace:"Mace",cart:"Cart",crystal:"Crystal",ely:"Ely",skills:"Sonstige Skills"};
const namesEn = {mace:"Mace",cart:"Cart",crystal:"Crystal",ely:"Ely",skills:"Other Skills"};
const modal = document.getElementById("strategyModal");
const modalTitle = document.getElementById("modalTitle");
const modalDescription = document.getElementById("modalDescription");

function clickSound() {
  if (!audioContext) return;
  const now = audioContext.currentTime;
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(620, now);
  osc.frequency.exponentialRampToValueAtTime(920, now + 0.055);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.035, now + 0.008);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.11);
  osc.connect(gain).connect(audioContext.destination);
  osc.start(now);
  osc.stop(now + 0.12);
}

document.querySelectorAll(".strategy-card").forEach(card => {
  card.addEventListener("click", () => {
    const key = card.dataset.category;
    modalTitle.textContent = currentLanguage === "en" ? namesEn[key] : names[key];
    modalDescription.textContent = currentLanguage === "en" ? descriptionsEn[key] : descriptions[key];
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    clickSound();
  });
});
function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
}
document.querySelectorAll("[data-close]").forEach(el => el.addEventListener("click", closeModal));
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

let audioContext = null;
let musicNodes = [];
let musicOn = false;
let musicVolume = 0.035;
const musicToggle = document.getElementById("musicToggle");
const musicLabel = document.getElementById("musicLabel");

function startAmbientMusic() {
  audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)();
  if (audioContext.state === "suspended") audioContext.resume();
  stopAmbientMusic();
  const master = audioContext.createGain();
  master.gain.value = musicVolume;
  master.connect(audioContext.destination);
  musicNodes.push(master);

  // Original, softly synthesized ambient pad – no external music file needed.
  const notes = [110, 164.81, 220, 261.63];
  notes.forEach((freq, i) => {
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    const filter = audioContext.createBiquadFilter();
    osc.type = i % 2 ? "triangle" : "sine";
    osc.frequency.value = freq;
    filter.type = "lowpass";
    filter.frequency.value = 520;
    gain.gain.value = i === 0 ? 0.22 : 0.10;
    osc.connect(filter).connect(gain).connect(master);
    osc.start();
    musicNodes.push(osc, gain, filter);
  });
  musicOn = true;
  musicToggle.classList.add("playing");
  musicToggle.setAttribute("aria-pressed", "true");
  musicLabel.textContent = translations[currentLanguage].musicOn;
}
function stopAmbientMusic() {
  musicNodes.forEach(node => {
    try { if (typeof node.stop === "function") node.stop(); } catch (_) {}
    try { if (typeof node.disconnect === "function") node.disconnect(); } catch (_) {}
  });
  musicNodes = [];
  musicOn = false;
  musicToggle.classList.remove("playing");
  musicToggle.setAttribute("aria-pressed", "false");
  musicLabel.textContent = translations[currentLanguage].musicOff;
}
musicToggle.addEventListener("click", () => {
  if (musicOn) stopAmbientMusic();
  else startAmbientMusic();
});
document.getElementById("volumeButton").addEventListener("click", () => {
  musicVolume = musicVolume >= 0.055 ? 0.018 : musicVolume + 0.018;
  const master = musicNodes.find(node => node instanceof GainNode);
  if (master) master.gain.setTargetAtTime(musicVolume, audioContext.currentTime, 0.08);
  document.getElementById("volumeButton").title = `Musiklautstärke: ${Math.round(musicVolume * 1000)} / 100`;
  clickSound();
});
document.getElementById("year").textContent = new Date().getFullYear();
document.querySelectorAll("a[href^='#']").forEach(link => link.addEventListener("click", clickSound));

document.getElementById("languageToggle").addEventListener("click", () => {
  applyLanguage(currentLanguage === "de" ? "en" : "de");
  clickSound();
});
